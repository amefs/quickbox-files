from deluge.ui.console.cmdline.command import BaseCommand

__all__ = ['BaseCommand']
