## [Transmission 2.84](https://trac.transmissionbt.com/query?milestone=2.84&group=component&order=severity) (2014-07-01)
### All Platforms
 * Fix peer communication vulnerability (no known exploits) reported by Ben Hawkes
