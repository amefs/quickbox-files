from deluge.ui.console.modes.preferences.preferences import Preferences

__all__ = ['Preferences']
